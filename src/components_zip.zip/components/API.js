fetch('https://api-mainnet.magiceden.dev/v2/collections/bigheadbillions/listings')
.then(res => console.log(res))