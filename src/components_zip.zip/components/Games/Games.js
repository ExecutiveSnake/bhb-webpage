import React from 'react';
import BurgerBuilder from './BurgerBuilder/BurgerBuilder';

const Games = () => {
    return (
        <div>
            <h1>Games</h1>
            {/* <BurgerBuilder /> */}
        </div>

    )
}

export default Games;